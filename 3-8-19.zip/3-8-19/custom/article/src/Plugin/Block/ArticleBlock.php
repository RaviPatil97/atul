<?php
/**
 * @file
 * Contains \Drupal\article\Plugin\Block\ArticleBlock.
 */

namespace Drupal\article\Plugin\Block;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Session\AccountProxyInterface;

class ArticleBlock extends BlockBase implements BlockPluginInterface {
	
	 protected $currentUser;
	 $output=[];
  /**
   * {@inheritdoc}
   */
	public function __construct(AccountProxyInterface $current_user) {
		
    $this->currentUser = $current_user;
	}
	 
	 public function blockForm($form, FormStateInterface $form_state) {
		 
    $form = parent::blockForm($form, $form_state);

    $config = $this->getConfiguration();

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('subscribe'),
      '#button_type' => 'primary',
    );
    return $form;
  }
  
  /**
   * Custom submit actions
   */
	 public function custom_submit_form($form, FormStateInterface $form_state) {
    
	
	array_push($output,$this->currentUser);
	drupal_set_message($this->currentUser->getDisplayName());
    //Perform the required actions
  }
}