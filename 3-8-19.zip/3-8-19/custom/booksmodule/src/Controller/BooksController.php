<?php
namespace Drupal\booksmodule\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
class BooksController extends ControllerBase
{
	protected $listbooks;
     public function __construct(ListBooks $listbooks)
    {
        $this->listbooks = $listbooks;
    }
	
	
	public static function create(ContainerInterface $container)
    {
        return new static(
		$container->get('techbooks.listbooks');
		);
    }
	 public function demo (){
		 
		return [ '#markup'=>$this->listbooks->getBooks()
		];
		
	 }
   
}

?>