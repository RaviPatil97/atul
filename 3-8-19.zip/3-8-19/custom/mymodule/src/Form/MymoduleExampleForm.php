<?php
    namespace Drupal\mymodule\Form;
	
    use Drupal\Core\Form\FormBase;
    use Drupal\Core\Form\FormStateInterface;
    /**
     * Class MymoduleExampleForm for demostration.
    */
    class MymoduleExampleForm extends FormBase {
      /**
       * {@inheritdoc}
      */
      public function getFormId() {
        return 'mymodule_example_form';
      }
      /**
       * {@inheritdoc}
      */
      public function buildForm(array $form, FormStateInterface $form_state) {
        
        $form['actions']['#type'] = 'actions';
        $form['actions']['submit'] = [
         '#type' => 'submit',
         '#value' => $this->t('Subscribe'),
        ];
        return $form;
      }
      /**
       * {@inheritdoc}
      */
      public function validateForm(array &$form, FormStateInterface $form_state) {
        // Nothing.
      }
      /**
       * {@inheritdoc}
      */
      public function submitForm(array &$form, FormStateInterface $form_state) {
        drupal_set_message($this->t('@user_email ,Your email-id has been sent !', ['@user_email' => $form_state-  >getValue('user_mail')]));}
    }