 <?php
    namespace Drupal\mymodule\Plugin\Block;

    use Drupal\Core\Block\BlockBase;

    /**
     * Provides a 'MymoduleExampleBlock' block.
     *
     * @Block(
     *   id = "mymodule_example_block",
     *   admin_label = @Translation("Example block"),
     *   category = @Translation("Custom example block")
     * )
    */
    class MymoduleExampleBlock extends BlockBase {

     /**
      * {@inheritdoc}
     */
     public function build() {

       $form = \Drupal::formBuilder()->getForm('Drupal\mymodule\Form\MymoduleExampleForm');

       return $form;
     }
   }