<?php

namespace  Drupal\hello_world\Controller;

class HelloWorldController {
    public function hello() {
        return array(
            '#title' => 'Hello Viewers!',
            '#markup' => 'Welcome to Drupal Website :)'
        );
    }

}