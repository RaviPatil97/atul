<?php

namespace Drupal\cow_service\Services;
use Drupal\Core\Session\AccountProxy;
use GuzzleHttp\Client

/**
 * CowService is a simple example of a Drupal8 Service
 */
class CowService {

    
    protected $current_user;
	protected $http_client;
    
    public function __construct(AccountProxy $currentUser,Client $http_client ) {
        $this->current_user = $currentUser;
		$this->$http_client = $http_client;
    }

    
    /**
     * Returns a cow sound 
     */
    public function demo() {
		$posts=[];
		$output=[];
        
		$request = $this->httpClient->request('GET', 'https://jsonplaceholder.typicode.com/photos');
		
		$posts = $request->getBody()->getContents();
		foreach ($posts as $key => $value) {
		$output = '<img src="' . $posts ['url']. '"/>';
		return $output;
    }
    
    

}