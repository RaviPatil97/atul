<?php

namespace Drupal\gallery\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\gallery\Services\Gallery;

class CowserviceController extends ControllerBase {

	protected $gallery;

	public function __construct(Gallery $gallery) {
        $this->gallery = $gallery;
	}
	
	public static function create(ContainerInterface $container){
		return new static(
			$container->get('gallery.demo')
		);
	}
	
	public function demo() {		
		return ['#markup' =>  $this->gallery->demo()];
	}
}